# bot.py
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, LabeledPrice

TOKEN = "7373747"  # توکن ربات
ADMIN_CHAT_ID = 83838399      # آیدی عددی خودت یا مدیر ربات
bot = telebot.TeleBot(TOKEN)

# دستور /vipaccount
@bot.message_handler(commands=['start'])
def start(message):
    markup = InlineKeyboardMarkup()
    buy_btn = InlineKeyboardButton("پرداخت تستی", callback_data="buy")
    markup.add(buy_btn)
    bot.send_message(
        message.chat.id,
        "سلام 👋\nبرای خرید اشتراک vipروی دکمه زیر بزن:",
        reply_markup=markup
    )

# دکمه خرید
@bot.callback_query_handler(func=lambda call: call.data == "buy")
def send_invoice(call):
    prices = [LabeledPrice(label="پرداخت هزینه اشتراک", amount=1)]  # 1 = 1.00 واحد پول تستی
    bot.send_invoice(
        chat_id=call.message.chat.id,
        title="خرید اشتراک Vip",
        description="با زدن روی دکمه زیر و پرداخت هزینه اشتراک حساب شما بصورت خودکار در ربات وی آی پی خواهد شد🌟",
        invoice_payload="test_payment",
        provider_token="",  # ← برای Stars اینجا خالی بذار
        currency="XTR",     # واحد Stars
        prices=prices,
        start_parameter="test_payment"
    )

# پاسخ pre_checkout
@bot.pre_checkout_query_handler(func=lambda query: True)
def pre_checkout(query):
    bot.answer_pre_checkout_query(query.id, ok=True)

# پرداخت موفق
@bot.message_handler(content_types=['successful_payment'])
def payment_success(message):
    stars = message.successful_payment.total_amount / 100
    bot.send_message(
        message.chat.id,
        f"✅ پرداخت موفق!\nشما {stars} Telegram Stars پرداخت کردید 🌟"
    )

    # ارسال اطلاعات کاربر به مدیر
    user_id = message.from_user.id
    username = message.from_user.username or "ندارد"
    full_name = (message.from_user.first_name or "") + " " + (message.from_user.last_name or "")
    sp = message.successful_payment
    amount = sp.total_amount
    currency = sp.currency
    charge_id = getattr(sp, 'telegram_payment_charge_id', 'N/A')

    admin_text = f"""
پرداخت موفق ✅
کاربر: {full_name} @{username}
شناسه عددی: {user_id}
مبلغ: {amount} {currency}
payment_id: {charge_id}
"""
    bot.send_message(ADMIN_CHAT_ID, admin_text)

print("ربات آماده‌ست ✅")
bot.infinity_polling()